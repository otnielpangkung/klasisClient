import Vue from 'vue'
import Vuex from 'vuex'
import axios from "../API/axios"

Vue.use(Vuex)

export default new Vuex.Store({
  state: {
    amaCabang: "",
    jenisTransaksi: [],
    transaksiUser: [],
    kelMa: [],
    saldoUser: [],
    mataAnggaran: [],
    anggarans: [],
    isLogin: false
  },
  mutations: {
    setUserLogin(state, data) {
      state.isLogin = data
    },
    setjenisTransaksi(state, data) {
      state.jenisTransaksi = data
    },
    setKelMa(state, data) {
      state.kelMa = data
    },
    setTransaksiUser(state, data) {
      state.transaksiUser = data
    },
    setSaldoUser(state, data) {
      state.saldoUser = data
    },
    setMataANggaran(state, data) {
      state.mataAnggaran = data
    },
    setUserLogin(state, data) {
      state.isLogin = data
    },
    setAnggarans(state, data) {
      state.anggarans = data
    },

  },
  actions: {
    fetchJenisTransaksi(context) {
      return axios.get("/database/jenistransaksi")
        .then(({ data }) => {
          context.commit("setjenisTransaksi", data)
        })
        .catch(err => {
          console.log(err);
        })
    },
    fetchKelMa(context) {
      return axios
        .get(`/database/kelma`, {
          headers: {
            access_token: localStorage.getItem("access_token")
          }
        })
        .then(({ data }) => {
          context.commit("setKelMa", data)
        })
        .catch(err => {
          console.log(err);
        });
    },
    getTransaksiUser(context) {
      return axios.get("/transaksi/jemaat", {
        headers: {
          access_token: localStorage.getItem("access_token")
        }
      }).then(({ data }) => {
        // console.log(data, "===========");
        context.commit("setTransaksiUser", data)
      }).catch(err => {
        console.log(err);
      })
    },
    getSaldo(context) {
      return axios.get("/database/saldo", {
        headers: {
          access_token: localStorage.getItem("access_token")
        }
      }).then(({ data }) => {
        // console.log(data, "===========");
        context.commit("setSaldoUser", data)
      }).catch(err => {
        console.log(err);
      })
    },
    getMataAnggaran(context) {
      return axios.get("/database/mataanggaran", {
        headers: {
          access_token: localStorage.getItem("access_token")
        }
      }).then(({ data }) => {
        // console.log(data, "===========");
        context.commit("setMataANggaran", data)
      }).catch(err => {
        console.log(err);
      })
    },
    getAnggaran(context) {
      return axios.get("/transaksi/anggaran", {
        headers: {
          access_token: localStorage.getItem("access_token")
        }
      }).then(({ data }) => {
        context.commit("setAnggarans", data)
      }).catch(err => {
        console.log(err);
      })
    },

  },
  modules: {
  }
})

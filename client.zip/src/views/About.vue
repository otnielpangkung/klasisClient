<template>
  <div class="about">
    <h1>This is an about page</h1>
    <button @click.prevent="test()"></button>
    <i class="fas fa-thumbs-up"></i>
  </div>
</template>
<script>
import Swal from "sweetalert2";
export default {
  methods: {
    test() {
      Swal.fire("The Internet?", "That thing is still around?", "success");
    }
  }
};
</script>
<template>
  <div class="AllTransaksi">
    <div class="title">Daftar Transaksi</div>
    <!-- {{this.filterData()}} -->
    <button
      v-if="this.role == 'bendahara'"
      type="button"
      @click.prevent="showAdd()"
      class="btn btn-primary"
    >Tambah Transaksi</button>
    <!-- Modal -->
    <div class="modal fade" id="myModal" role="dialog">
      <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
          <div class="modal-body">
            <form @submit.prevent="editStatus ? editTransaksi() : inputTransaksi()">
              <div class="form-row">
                <div class="col-sm">
                  <label class="my-1 mr-2" for="Transaksi">Nama Transaksi</label>
                  <div class="input-group">
                    <input
                      v-model="namaTransaksi"
                      type="text"
                      id="User_ID"
                      class="form-control"
                      placeholder="Isi Nama Transaksi..."
                      required
                    />
                    <input
                      type="date"
                      v-model="tanggalTransaksi"
                      id="User_ID"
                      class="form-control"
                      required
                    />
                  </div>
                </div>
                <div class="col-sm">
                  <label class="my-1 mr-2" for="Username">Jenis Transaksi</label>
                  <div class="input-group">
                    <select class="form-control" v-model="JenisTransaksiId" required>
                      <option selected disabled>Pilih Jenis Transaksi</option>
                      <option
                        v-for="jenis in this.jenisTransaksiList"
                        :key="jenis.id"
                        :value="jenis.id"
                      >{{jenis.namaJenis}}</option>
                    </select>
                  </div>
                </div>
              </div>
              <div class="form-row">
                <div class="col-sm">
                  <label for="Harga" class="my-1 mr-2">Nominal</label>
                  <div class="input-group">
                    <div class="input-group-prepend">
                      <span class="input-group-text" id="Rp">Rp</span>
                    </div>
                    <input type="number" v-model="jumlah" class="form-control" required />
                  </div>
                  <label class="my-1 mr-2" for="kelompokMA">Kelompok Mata Anggaran</label>
                  <div class="input-group">
                    <select class="form-control" v-model="KelompokMAId" required>
                      <option
                        v-for="kelompok in getKelMa()"
                        :key="kelompok.id"
                        :value="kelompok.id"
                      >{{kelompok.namaKelMa}}</option>
                    </select>
                  </div>
                  <label class="my-1 mr-2" for="MataAnggaran">Mata Anggaran</label>
                  <div class="input-group">
                    <select class="form-control" v-model="MataAnggaranId" required>
                      <option
                        v-for="mataanggaran in getMa()"
                        :key="mataanggaran.id"
                        :value="mataanggaran.id"
                      >{{mataanggaran.namaMataAnggaran}}</option>
                    </select>
                  </div>
                </div>
                <div class="col-sm">
                  <label class="my-1 mr-2" for="Keterangan">Keterangan:</label>
                  <div class="input-group">
                    <textarea class="form-control" v-model="keterangan" rows="7"></textarea>
                  </div>
                  <div class="d-flex justify-content-end my-2">
                    <button type="submit" class="btn btn-primary">Submit</button>
                  </div>
                </div>
              </div>
            </form>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
          </div>
        </div>
      </div>
    </div>
    <!--  -->
    <div class="row justify-content-md-center mt-1">
      <div class="col">
        <div class="row justify-content-start mb-3">
          <div class="input-group col-sm col-lg-5">
            <label class="my-1 mr-2" for="Username">Tanggal :</label>
            <input type="date" class="form-control mr-3" v-model="startDate" /> -
            <input type="date" class="form-control ml-3" v-model="endDate" />
          </div>
        </div>
      </div>
      <button class="btn" @click.prevent="tableHtmlToExcel('tableTransaksi')">
        <i class="fa fa-download"></i> Download
      </button>
      <div class="table2 row">
        <div class="tableView justify-self-center">
          <table class="table table-hover table-bordered table-striped" id="tableTransaksi">
            <thead>
              <tr class>
                <th scope="col">No</th>
                <th scope="col">Nama Transaksi</th>
                <th scope="col">Tanggal Transaksi</th>
                <th scope="col">Jenis Transaksi</th>
                <th scope="col">Mata Anggaran</th>
                <th scope="col">Keterangan</th>
                <th scope="col">Jumlah</th>
                <!-- <th scope="col">status</th> -->
                <th scope="col">Action</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="list in filterData()" :key="list.id">
                <th scope="row">{{list.id}}</th>
                <td>{{list.namaTransaksi}}</td>
                <td class="text-center">{{ formatTanggal(list.tanggalTransaksi)}}</td>
                <td>{{list.KelompokMA.namaKelMa}}</td>
                <td>{{list.MataAnggaran.namaMataAnggaran}}</td>
                <td>{{list.keterangan}}</td>
                <td id="uang">{{ formatUang(list.jumlah)}}</td>
                <!-- <td>{{list.status}}</td> -->
                <td class="action">
                  <a @click.prevent="confirmDelete(list.id)">
                    <i class="fas fa-trash-alt" title="hapus"></i>
                  </a>
                  <a @click.prevent="showEdit(list)">
                    <i class="fas fa-edit" title="edit"></i>
                  </a>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import axios from "../API/axios";
import Swal from "sweetalert2";
import moment from "moment";

export default {
  name: "AllTransaksi",
  data() {
    return {
      editStatus: false,
      startDate: "",
      endDate: "",
      showModal: true,
      id: 0,
      namaTransaksi: "",
      keterangan: "",
      tanggalTransaksi: "",
      MataAnggaranId: 0,
      jumlah: 0,
      JenisTransaksiId: 0,
      KelompokMAId: 0,
      keterangan: ""
    };
  },
  computed: {
    jenisTransaksiList() {
      return this.$store.state.jenisTransaksi;
    },
    kelma() {
      return this.$store.state.kelMa;
    },
    mataanggaran() {
      return this.$store.state.mataAnggaran;
    },
    transaksiUser() {
      return this.$store.state.transaksiUser;
    },
    namaJemaat() {
      return localStorage.getItem("namaJemaat");
    },
    role() {
      return localStorage.getItem("role");
    }
  },
  created() {
    this.$store.dispatch("getTransaksiUser");
    this.$store.dispatch("fetchJenisTransaksi");
    this.$store.dispatch("fetchKelMa");
    this.$store.dispatch("getMataAnggaran");
  },
  methods: {
    showAdd() {
      $("#myModal").modal("show");
      this.editStatus = false;
      this.id = 0;
      this.namaTransaksi = "";
      this.keterangan = "";
      this.tanggalTransaksi = "";
      this.MataAnggaranId = 0;
      this.jumlah = 0;
      this.JenisTransaksiId = 0;
      this.KelompokMAId = 0;
      this.keterangan = "";
    },
    filterData() {
      let hasil = [];
      if (!this.startDate || !this.endDate) {
        hasil = this.transaksiUser;
      } else {
        this.transaksiUser?.map(item => {
          let start = moment(this.startDate, "YYYY/MM/DD") - 1;
          let end = moment(this.endDate, "YYYY/MM/DD") + 1;

          let tanggalItem = moment(item.tanggalTransaksi, "YYYY/MM/DD");
          if (tanggalItem.isBetween(start, end) == true) {
            hasil.push(item);
          }
        });
      }
      return hasil;
    },
    editTransaksi() {
      let payload = {
        namaTransaksi: this.namaTransaksi,
        keterangan: this.keterangan,
        tanggalTransaksi: this.tanggalTransaksi,
        MataAnggaranId: +this.MataAnggaranId,
        jumlah: +this.jumlah,
        JenisTransaksiId: +this.JenisTransaksiId,
        KelompokMAId: +this.KelompokMAId
      };

      return axios
        .put(`/transaksi/${this.id}`, payload, {
          headers: {
            access_token: localStorage.getItem("access_token")
          }
        })
        .then(({ data }) => {
          this.$store.dispatch("getTransaksiUser");
          this.$store.dispatch("getTransaksiUser");
          this.$store.dispatch("getTransaksiUser");
          this.$store.dispatch("getTransaksiUser");
          Swal.fire({
            title: "Berhasil",
            text: "Data Berhasil Di Edit",
            icon: "success",
            confirmButtonText: "Ok"
          });

          $("#myModal").modal("hide");
          // console.log(data);
        })
        .catch(err => {
          Swal.fire("Maaf", "Periksa Kembali Data Anda", "error");
          console.log(err);
        });
    },
    formatTanggal(data) {
      let hasil = "";
      var time = moment(data).format("DD-MM-YYYY h:mm:ss");
      hasil = time.slice(0, 10);
      return hasil;
    },
    formatUang(data) {
      // console.log(data, "dataa");
      let uang = "";
      data = data.toString();
      for (let i = 0; i < data.length; i++) {
        if ((data.length - i) % 3 == 0 && i !== 0) {
          uang += `.${data[i]}`;
        } else {
          uang += data[i];
        }
      }
      return uang;
    },
    confirmDelete(id) {
      Swal.fire({
        title: "Yakin?",
        text: "Apakah Yakin ",
        icon: "question",
        showCancelButton: true,
        confirmButtonColor: "#3085d6",
        cancelButtonColor: "#d33",
        confirmButtonText: "Hapus!!"
      }).then(result => {
        if (result.isConfirmed) {
          this.deleteTransaksi(id);
          this.$store.dispatch("getTransaksiUser");
          Swal.fire("Deleted!", "Data Berhasil Dihapus", "success");
          // this.$router.push("/report/transaksi");
        } else {
          Swal.fire("Ok", "Proses anda berhasil dibatalkan", "error");
        }
      });
    },
    deleteTransaksi(id) {
      return axios
        .delete(`/transaksi/${id}`, {
          headers: {
            access_token: localStorage.getItem("access_token")
          }
        })
        .then(data => {
          this.$store.dispatch("getTransaksiUser");
          this.$store.dispatch("getTransaksiUser");
          this.$store.dispatch("getTransaksiUser");
          this.$store.dispatch("getTransaksiUser");
          this.$store.dispatch("getTransaksiUser");
          this.$store.dispatch("getTransaksiUser");
          this.$store.dispatch("getTransaksiUser");
          this.$store.dispatch("getTransaksiUser");
          this.$store.dispatch("getTransaksiUser");
          this.$store.dispatch("getTransaksiUser");
        });
    },
    inputTransaksi() {
      let payload = {
        namaTransaksi: this.namaTransaksi,
        keterangan: this.keterangan,
        tanggalTransaksi: this.tanggalTransaksi,
        MataAnggaranId: +this.MataAnggaranId,
        jumlah: +this.jumlah,
        JenisTransaksiId: +this.JenisTransaksiId,
        KelompokMAId: +this.KelompokMAId
      };

      return axios
        .post("/transaksi", payload, {
          headers: {
            access_token: localStorage.getItem("access_token")
          }
        })
        .then(({ data }) => {
          this.$store.dispatch("getTransaksiUser");
          this.$store.dispatch("getTransaksiUser");
          this.$store.dispatch("getTransaksiUser");
          this.$store.dispatch("getTransaksiUser");
          Swal.fire({
            title: "Berhasil",
            text: "Data Berhasil Ditambahkan",
            icon: "success",
            confirmButtonText: "Ok"
          });
          this.$router.push("/report/transaksi");
          $("#myModal").modal("hide");
          // console.log(data);
        })
        .catch(err => {
          Swal.fire("Maaf", "Periksa Kembali Data Anda", "error");
          console.log(err);
        });
    },
    showEdit(item) {
      $("#myModal").modal("show");
      this.editStatus = true;
      this.namaTransaksi = item.namaTransaksi;
      this.keterangan = item.keterangan;
      this.JenisTransaksiId = item.JenisTransaksiId;
      this.KelompokMAId = item.KelompokMAId;
      this.MataAnggaranId = item.MataAnggaranId;
      this.tanggalTransaksi = item.tanggalTransaksi;
      this.jumlah = item.jumlah;
      this.id = item.id;
    },

    getKelMa() {
      let hasil = [];
      this.kelma?.map(item => {
        if (item.JenisTransaksiId == this.JenisTransaksiId) {
          hasil.push(item);
        }
      });
      return hasil;
    },
    getMa() {
      let hasil = [];
      this.mataanggaran?.map(item => {
        if (item.KelompokMAId == this.KelompokMAId) {
          hasil.push(item);
        }
      });
      return hasil;
    },
    periode() {
      let hasil = "";
      if (!this.startDate || !this.endDate) {
        hasil = "-";
      } else {
        hasil = `${this.startDate} sampai ${this.endDate}`;
      }
      return hasil;
    },
    tableHtmlToExcel(
      tableID,
      filename = `Laporan Bulanan Jem. ${
        this.namaJemaat
      } Periode ${this.periode()}`
    ) {
      // Download Transaksi
      var downloadLink;
      var dataType = "application/vnd.ms-excel";
      var tableSelect = document.getElementById(tableID);
      var tableHTML = tableSelect.outerHTML.replace(/ /g, "%20");

      filename = filename ? filename + ".xls" : "excel_data.xls";

      downloadLink = document.createElement("a");

      document.body.appendChild(downloadLink);

      if (navigator.msSaveOrOpenBlob) {
        var blob = new Blob(["\ufeff", tableHTML], {
          type: dataType
        });
        navigator.msSaveOrOpenBlob(blob, filename);
      } else {
        downloadLink.href = "data:" + dataType + ", " + tableHTML;

        downloadLink.download = filename;

        downloadLink.click();
      }
    }
  }
};
</script>

<style scoped>
.AllTransaksi {
  width: 85vw;
}
thead tr {
  /* background-color: #1b9aaa; */
  color: #0040b8;
  font-weight: normal;
  font-size: 14px;
}
.title {
  font-weight: 700;
  padding: 0 15px;
  font-size: 30px;
  margin: 25px 0;
}
.periode {
  font-size: 18px;
}
td {
  text-align: left;
}
.action {
  text-align: center;
  font-size: 20px;
}

.svg-inline--fa {
  margin-right: 5px;
}
table th {
  text-align: center;
}
table th,
td {
  padding: 8px 0;
  font-size: 14px;
}
tbody td {
  text-align: left;
}
#uang {
  text-align: right;
}
.table2 {
  justify-content: center;
}
table {
  min-width: 2500px;
}
.tableView {
  width: 85vw;
  max-height: 600px;
  overflow-x: scroll;
  overflow-y: scroll;
  justify-self: center;
}
@media screen and(max-width: 800px) {
  table th,
  td {
    padding: 8px 0;
    font-size: 12px;
  }
  .tableView {
    padding-left: 20px;
  }
  .AllTransaksi {
    width: 100vw;
  }
}
</style>